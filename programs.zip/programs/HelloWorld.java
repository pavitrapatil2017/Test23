package hwpackage;
import trainerpack.Trainer;
//import packagename.classname;

class HelloWorld
{
public static void main(String[] ar)
{
System.out.println("HelloWorld");
Student student =new Student();
student.displaySName();

Trainer trainer =new Trainer();
trainer.displayTName();
}
}