package trainerpack;
public class Trainer
{
String tName="Pavitra";//null

public void displayTName()
{
System.out.println(tName);
}
}