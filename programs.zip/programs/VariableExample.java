//java.lang
/*
*
*
*
*/
import java.util.Scanner;
class VariableExample
{
public static void main(String[] ar)
{
Scanner scanner =new Scanner(System.in);//java.util 
System.out.println("enter the integer value");
int num1=scanner.nextInt();
System.out.println("enter the byte value");
byte bnum=scanner.nextByte();
System.out.println("enter the short value");
short snum=scanner.nextShort();
System.out.println("enter the long value");
long lnum=scanner.nextLong();
char ch='a';
System.out.println("enter the boolean value");
boolean flag=scanner.nextBoolean();
System.out.println("enter the float value");
float f=scanner.nextFloat();
System.out.println("enter the double value");
double salary=scanner.nextDouble();
/*System.out.println("byte     "+bnum+" \n  short    " +snum + "  int   "+num1);
System.out.println();
System.out.println();*/
System.out.println("long    "+lnum);
System.out.println("char   "+ch);
System.out.println("boolean  "+flag);
System.out.println("float  "+f);
System.out.println("double   "+salary);

}
}