package hwpackage;
class Student
{
String sName="Edubridge";//null

void displaySName()
{
System.out.println(sName);
}
}